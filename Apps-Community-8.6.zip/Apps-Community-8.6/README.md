##### WANT TO HELP? CLICK THE ★ (STAR LOGO) in the Upper-Right! 
<p align="center">
  <a href="https://pgblitz.com/forums" target="_blank" /a><img src="https://pgblitz.com/wikipics/logo-forums.png" width="160"/>   
  <a href="https://github.com/PGBlitz/PGBlitz.com/wiki" target="_blank" /a><img src="https://pgblitz.com/wikipics/logo-wiki.png" width="160"/>
  <a href="https://pgblitz.com/threads/plexguide-install-instructions.243/" target="_blank" /a><img src="https://pgblitz.com/wikipics/logo-pg-install.png" width="160"/> 
  <a href="https://pgblitz.com/account/upgrades" target="_blank" /a><img src="https://pgblitz.com/wikipics/logo-donate.png" width="160"/>
</p>

* 📂 [**[Click Here]**](https://goo.gl/7NR3Da) - Google G-Suite (Unlimited Hard Drive Space & Storage)
* 📂 [**[Click Here]**](https://controlpanel.newshosting.com/signup/index.php?promo=partners&a_aid=5a65169240efd&a_bid=5ecfe99b) - Top Performance NewsHost! - Blitz Members Receive a 58% Discount
----
### **Reference Shortcut -** http://wiki.pgblitz.com
----

## 1. PG YouTube

<p align="center"><kbd><a href="https://youtu.be/joqL_zjl0pE" /a><img src="https://github.com/PGBlitz/Assets/blob/master/ycovers/mainintro.png" width="400"></kbd></p>
<p align="center"><b>PGBlitz Introduction Video</b></p>

<p align="center"><kbd><a href="https://youtu.be/8lotdbpsrUE" /a><img src="https://github.com/PGBlitz/Assets/blob/master/ycovers/introv10.png" width="400"></kbd></p>
<p align="center"><b>PGBlitz Installation Video</b></p>

[**[Click Here]**](https://pgblitz.com/threads/plexguide-install-instructions.243/) for installation instructions to start the process
