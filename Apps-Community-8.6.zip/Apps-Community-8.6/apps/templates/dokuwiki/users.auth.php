admin:$1$4fd0ad31$.cId7p1uxI4a.RcrH81On0:DokuWiki Administrator:mail@host.com:admin,user
